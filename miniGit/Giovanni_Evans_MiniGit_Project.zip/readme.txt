
Program functionality:

This program creates a doubly linked list which has singly linked lists connected to each one. 
The singly linked lists contains files with file verison and file names. We also have a subdirectory 
which can be used to save contentes from previous points in creating files. This is a mock of a higher level
GitHUB(version control system).
You have the option to either add, remove, commit changes, checkout , and quit.

add: adds files to the current cmmit instance
remove: removes files from the current commit instance
commit: changes current file contents
checkout: grab previous save points and make that your new current file contents
quit: quits the program


special features:

void showList(); outputs filename and file version of the current linked list contents. 
This prints everytme we add or remove something frome the current list.